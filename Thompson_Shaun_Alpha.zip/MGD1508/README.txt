Mobile Game Design 1508
Name: Shaun Thompson
GitHub: https://github.com/n38803/MGD1508

Orientation: Portrait
Hardware: iPhone 6

I haven’t had an opportunity to restrict orientation and really mess around with the formatting of my game’s world, so the above settings are the best to currently view the game.