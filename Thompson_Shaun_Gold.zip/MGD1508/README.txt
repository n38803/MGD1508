Mobile Game Design 1508
Name: Shaun Thompson
GitHub: https://github.com/n38803/MGD1508

Orientation: Landscape
Preferred Hardware: iPad Air

** Device does not have orientation restriction
** gravity parameters not configured
** splash screen complete but newly added graphics not matching storyboard layout