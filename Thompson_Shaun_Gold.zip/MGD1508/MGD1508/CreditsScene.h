//
//  CreditsScene.h
//  Doodle World
//
//  Created by Shaun Thompson on 8/28/15.
//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface CreditsScene : SKScene

@end
