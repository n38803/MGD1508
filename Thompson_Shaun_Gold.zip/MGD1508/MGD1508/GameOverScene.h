//
//  GameOverScene.h
//  MGD1508
//
//  Created by Shaun Thompson on 8/22/15.
//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameOverScene : SKScene

@end
