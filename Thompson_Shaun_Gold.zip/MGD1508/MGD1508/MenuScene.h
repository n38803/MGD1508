//
//  MenuScene.h
//  MGD1508
//
//  Created by Shaun Thompson on 8/21/15.
//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface MenuScene : SKScene

@end
