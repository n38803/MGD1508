Immersive Application Deployment 1509
Name: Shaun Thompson
GitHub: https://github.com/n38803/MGD1508


** For Optimal Performance:
Hardware: iPad Air
Orientation: Landscape


** Device does not have orientation restriction
** Gravity parameters not configured
** Interactive dialog currently when eating fish.
** Map added but not functional until more than 1 level