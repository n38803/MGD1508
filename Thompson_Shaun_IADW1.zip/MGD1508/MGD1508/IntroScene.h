//
//  IntroScene.h
//  Doodle World
//
//  Created by Shaun Thompson on 9/12/15.
//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface IntroScene : SKScene

@end
