//
//  IAD1509
//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import "GameOverScene.h"
#import "MenuScene.h"

@implementation GameOverScene

CGRect screenRect;
CGFloat screenHeight;
CGFloat screenWidth;


-(void)didMoveToView:(SKView *)view {
    /* Setup your scene here */

    
    // Grab screen parameters
    screenRect = [[UIScreen mainScreen] bounds];
    screenHeight = screenRect.size.height;
    screenWidth = screenRect.size.width;
    
    // Background image
    SKSpriteNode *bgImage = [SKSpriteNode spriteNodeWithImageNamed:@"paperbackground"];
    bgImage.position = CGPointMake(self.size.width/2, self.size.height/2);
    bgImage.zPosition = -50;
    bgImage.xScale = 1;
    bgImage.yScale = 1;
    [self addChild:bgImage];
    
    // Game Over Label
    SKLabelNode *gameOver = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    gameOver.text = @"GAME OVER";
    gameOver.zPosition = 100;
    gameOver.name = @"Game Over";
    gameOver.fontColor = [UIColor blackColor];
    gameOver.fontSize = 45;
    gameOver.position = CGPointMake(CGRectGetMidX(self.frame),
                                    CGRectGetMidY(self.frame)+200);
    [self addChild:gameOver];
    
    
    // Game Over Face
    SKSpriteNode *deadHero = [SKSpriteNode spriteNodeWithImageNamed:@"gameover"];
    deadHero.xScale = 1;
    deadHero.yScale = 1;
    deadHero.name = @"hero";
    deadHero.position = CGPointMake(CGRectGetMidX(self.frame),
                                 CGRectGetMidY(self.frame));
    [self addChild:deadHero];
    
    // Play Again Label
    SKLabelNode *play = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    play.text = @"[ Main Menu ]";
    play.zPosition = 100;
    play.name = @"Main Menu";
    play.fontColor = [UIColor blackColor];
    play.fontSize = 25;
    play.position = CGPointMake(CGRectGetMidX(self.frame),
                                    CGRectGetMidY(self.frame)-200);
    [self addChild:play];
    
    
    
    
    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInNode:self];
    SKNode *node = [self nodeAtPoint:location];
    
    // if next button touched, start transition to next scene
    if ([node.name isEqualToString:@"Main Menu"]) {
        NSLog(@"Player opted to play again");
        
        SKScene *myScene = [[MenuScene alloc] initWithSize:self.size];
        SKTransition *transition = [SKTransition doorsCloseHorizontalWithDuration:0.5];
        [self.view presentScene:myScene transition:transition];
    }
}


@end
