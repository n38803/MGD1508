//
//  GameViewController.h
//  MGD1508
//

//  Copyright (c) 2015 Shaun Thompson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface GameViewController : UIViewController

@end
