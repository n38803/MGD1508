Mobile Game Design 1508
Name: Shaun Thompson
GitHub: https://github.com/n38803/MGD1508

Orientation: Portrait
Preferred Hardware: iPad Air

** Device does not have orientation restriction as of yet
** gravity parameters removed until I figure out how I want my scoring to be determined
** Resizing works as planned, however, coding for platform position causes graphics to be pulled to bottom of screen which adds too much real-estate on the skyline.